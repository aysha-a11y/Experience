#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageEnhance, ImageOps, ImageFilter, ImageTk
import cv2
import numpy as np
import os
from deepface import DeepFace

class ImageProcessingGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Processing GUI")
        self.root.config(bg="#f0f0f0")  # Background color

        # Create a frame for buttons
        self.button_frame = tk.Frame(root, bg="#f0f0f0")
        self.button_frame.pack(pady=20)

        # Create buttons with a professional style
        button_style = {"font": ("Arial", 12), "bg": "#4CAF50", "fg": "white", "relief": "raised", "activebackground": "#45a049"}
        self.select_image_button = tk.Button(self.button_frame, text="Select Image", command=self.select_image, **button_style)
        self.enhance_button = tk.Button(self.button_frame, text="Enhance Image", command=self.enhance_image, **button_style)
        self.segment_button = tk.Button(self.button_frame, text="Segment Image", command=self.segment_image, **button_style)
        self.detect_faces_button = tk.Button(self.button_frame, text="Detect Faces", command=self.detect_faces, **button_style)  # Changed name here
        self.save_button = tk.Button(self.button_frame, text="Save Images", command=self.save_images, **button_style)
        self.realtime_emotion_button = tk.Button(self.button_frame, text="Real-time Emotion Detection", command=self.realtime_emotion_detection, **button_style)  # Added new button
        self.clear_images_button = tk.Button(self.button_frame, text="Clear Images", command=self.clear_images, **button_style)  # Added new button

        # Pack buttons with proper padding
        self.select_image_button.pack(side=tk.LEFT, padx=10)
        self.enhance_button.pack(side=tk.LEFT, padx=10)
        self.segment_button.pack(side=tk.LEFT, padx=10)
        self.detect_faces_button.pack(side=tk.LEFT, padx=10)  # Changed name here
        self.save_button.pack(side=tk.LEFT, padx=10)
        self.realtime_emotion_button.pack(side=tk.LEFT, padx=10)  # Added new button
        self.clear_images_button.pack(side=tk.LEFT, padx=10)  # Added new button

        # Create a frame for image display
        self.image_frame = tk.Frame(root, bg="#f0f0f0")
        self.image_frame.pack(pady=20)

        # Create labels for image display
        self.original_image_label = tk.Label(self.image_frame, bg="white")
        self.enhanced_image_label1 = tk.Label(self.image_frame, bg="white")
        self.enhanced_image_label2 = tk.Label(self.image_frame, bg="white")
        self.enhanced_image_label3 = tk.Label(self.image_frame, bg="white")
        self.enhanced_image_label4 = tk.Label(self.image_frame, bg="white")
        self.segmented_image_label1 = tk.Label(self.image_frame, bg="white")
        self.segmented_image_label2 = tk.Label(self.image_frame, bg="white")
        self.segmented_image_label3 = tk.Label(self.image_frame, bg="white")

        # Pack labels with proper padding
        self.original_image_label.grid(row=0, column=0, padx=10)
        self.enhanced_image_label1.grid(row=0, column=1, padx=10)
        self.enhanced_image_label2.grid(row=0, column=2, padx=10)
        self.enhanced_image_label3.grid(row=0, column=3, padx=10)
        self.enhanced_image_label4.grid(row=0, column=4, padx=10)
        self.segmented_image_label1.grid(row=1, column=0, padx=10)
        self.segmented_image_label2.grid(row=1, column=1, padx=10)
        self.segmented_image_label3.grid(row=1, column=2, padx=10)

        # Initialize image variables
        self.image = None
        self.image_enhanced1 = None
        self.image_enhanced2 = None
        self.image_enhanced3 = None
        self.image_filtered = None  # Variable to store filtered image
        self.image_segmented1 = None
        self.image_segmented2 = None
        self.image_segmented3 = None

    def select_image(self):
        # Open a file dialog to select an image
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg;*.jpeg;*.png;*.bmp;*.gif")])
        
        # Load the selected image
        if file_path:
            self.image = Image.open(file_path)

            # Display the original image
            self.display_image(self.original_image_label, self.image)

    def enhance_image(self):
        # Enhance the image using three different techniques
        self.image_enhanced1 = self.image.filter(ImageFilter.SHARPEN)
        self.image_enhanced2 = ImageOps.equalize(self.image)
        self.image_enhanced3 = ImageEnhance.Color(self.image).enhance(2.0)  # Power law enhancement
        
        # Apply Gaussian blur filter
        self.image_filtered = self.image.filter(ImageFilter.GaussianBlur(radius=0.75))  # Adjust radius as needed

        # Display the enhanced images including the filtered image
        self.display_image(self.enhanced_image_label1, self.image_enhanced1)
        self.display_image(self.enhanced_image_label2, self.image_enhanced2)
        self.display_image(self.enhanced_image_label3, self.image_enhanced3)
        self.display_image(self.enhanced_image_label4, self.image_filtered)  # Display the filtered image

    def segment_image(self):
        # Segment the image using two different techniques
        self.image_segmented1 = self.image.convert("L").point(lambda x: 0 if x < 128 else 255, mode="1")
        self.image_segmented2 = self.image.filter(ImageFilter.FIND_EDGES)
        self.image_segmented3 = self.region_based_segmentation(self.image)  # Region-based segmentation

        # Display the segmented images
        self.display_image(self.segmented_image_label1, self.image_segmented1)
        self.display_image(self.segmented_image_label2, self.image_segmented2)
        self.display_image(self.segmented_image_label3, self.image_segmented3)

    def region_based_segmentation(self, image):
        # Function to perform region-based segmentation
        # Here's a simple example using OpenCV

        # Convert image to grayscale
        gray_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)

        # Apply Otsu's thresholding
        _, thresholded_image = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Convert to BGR for display
        segmented_image = cv2.cvtColor(thresholded_image, cv2.COLOR_GRAY2BGR)

        # Find contours
        contours, _ = cv2.findContours(thresholded_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        # Draw contours
        for contour in contours:
            cv2.drawContours(segmented_image, [contour], -1, (0, 255, 0), 2)

        # Convert back to PIL Image
        segmented_image_pil = Image.fromarray(segmented_image)

        return segmented_image_pil

    def detect_faces(self):  
        # Perform face detection using Haar cascade classifier
        # Load the cascade
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        face_cascade = cv2.CascadeClassifier(cascade_path)

        # Convert image to grayscale
        gray_image = cv2.cvtColor(np.array(self.image), cv2.COLOR_RGB2GRAY)

        # Detect faces
        faces = face_cascade.detectMultiScale(gray_image, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        # Draw rectangles around the faces
        image_with_faces = np.array(self.image)
        for (x, y, w, h) in faces:
            cv2.rectangle(image_with_faces, (x, y), (x + w, y + h), (255, 0, 0), 2)

        # Convert back to PIL Image
        image_with_faces_pil = Image.fromarray(image_with_faces)

        # Display the image with detected faces
        self.display_image(self.original_image_label, image_with_faces_pil)

    def realtime_emotion_detection(self):
        # Load face cascade classifier
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

        # Start capturing video
        cap = cv2.VideoCapture(0)

        while True:
            # Capture frame-by-frame
            ret, frame = cap.read()

            # Convert frame to grayscale
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Convert grayscale frame to RGB format
            rgb_frame = cv2.cvtColor(gray_frame, cv2.COLOR_GRAY2RGB)

            # Detect faces in the frame
            faces = face_cascade.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

            for (x, y, w, h) in faces:
                # Extract the face ROI (Region of Interest)
                face_roi = rgb_frame[y:y + h, x:x + w]

                # Perform emotion analysis on the face ROI
                result = DeepFace.analyze(face_roi, actions=['emotion'], enforce_detection=False)

                # Determine the dominant emotion
                emotion = result[0]['dominant_emotion']

                # Draw rectangle around face and label with predicted emotion
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
                cv2.putText(frame, emotion, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)

            # Display the resulting frame
            cv2.imshow('Real-time Emotion Detection', frame)

            # Press 'q' to exit
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        # Release the capture and close all windows
        cap.release()
        cv2.destroyAllWindows()

    def display_image(self, label, image):
        # Resize the image to fit the label
        image = image.resize((300, 300))

        # Convert the image to Tkinter format
        image_tk = ImageTk.PhotoImage(image)

        # Update the label with the new image
        label.configure(image=image_tk)
        label.image = image_tk

    def save_images(self):
        if (
            self.image_enhanced1 is None
            or self.image_enhanced2 is None
            or self.image_enhanced3 is None
            or self.image_filtered is None
            or self.image_segmented1 is None
            or self.image_segmented2 is None
            or self.image_segmented3 is None
        ):
            messagebox.showwarning("Warning", "No processed images to save.")
            return

        save_dir = filedialog.askdirectory()
        if save_dir:
            self.image_enhanced1.save(os.path.join(save_dir, "enhanced_image1.jpg"))
            self.image_enhanced2.save(os.path.join(save_dir, "enhanced_image2.jpg"))
            self.image_enhanced3.save(os.path.join(save_dir, "enhanced_image3.jpg"))
            self.image_filtered.save(os.path.join(save_dir, "enhanced_image4.jpg"))
            self.image_segmented1.save(os.path.join(save_dir, "segmented_image1.jpg"))
            self.image_segmented2.save(os.path.join(save_dir, "segmented_image2.jpg"))
            self.image_segmented3.save(os.path.join(save_dir, "segmented_image3.jpg"))

            messagebox.showinfo("Success", "Images saved successfully.")

    def clear_images(self):
        # Clear displayed images and reset image variables
        self.original_image_label.config(image="")
        self.enhanced_image_label1.config(image="")
        self.enhanced_image_label2.config(image="")
        self.enhanced_image_label3.config(image="")
        self.enhanced_image_label4.config(image="")
        self.segmented_image_label1.config(image="")
        self.segmented_image_label2.config(image="")
        self.segmented_image_label3.config(image="")

        self.image = None
        self.image_enhanced1 = None
        self.image_enhanced2 = None
        self.image_enhanced3 = None
        self.image_filtered = None
        self.image_segmented1 = None
        self.image_segmented2 = None
        self.image_segmented3 = None

# Create the main window
root = tk.Tk()

# Create the GUI object
gui = ImageProcessingGUI(root)

# Start the main event loop
root.mainloop()


# In[2]:


pip install tf_keras


# In[ ]:




